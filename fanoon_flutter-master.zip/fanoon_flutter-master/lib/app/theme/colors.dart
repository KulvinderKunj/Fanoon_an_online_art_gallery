import 'package:flutter/material.dart';

const red = Color(0xffEE1937);
const yellow = Color(0xffFDF100);
const green = Color(0xff37BBC8);
const darkGreen = Color(0xff01484F);
const orange = Color(0xffF46E3B);
const darkBlue = Color(0xff01314F);
const white = Color(0xfffffffF);
const grey = Color(0xff636A7D);
const lightGrey = Color(0xffA7B2CD);
