import 'package:funoon/features/Authentication/data/datasources/API/auth_api.dart';
import 'package:get_it/get_it.dart';

final sl = GetIt.instance;

void init() {
  //! Features - Number Trivia
  
  
 

  //! External
}
